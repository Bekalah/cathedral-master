# @cathedral/labs

Collaborative learning spaces and real-time tools.

- Shared canvas
- Frequency visualization
- WebRTC/SignalR integration (future)
