// Cathedral Alchemy Layers Index
// Export all alchemical layers for use in Cathedral apps

import layers from './layers.json';

export const alchemyLayers = layers.layers;

export default alchemyLayers;
