# Cymatics Engine (placeholder)

Source of truth lives under `external/cathedral-master/packages/web-platform/`.

- If Replit or a static host needs the file at runtime, copy the minimal browser file here and reference it in your page.
- This folder is published to the static site at `/engines/cymatics/`.
- Provenance: see `/external/PROVENANCE.md` for the imported paths and commit refs.

Minimal usage goal: do not ship heavy engines unless a page explicitly imports them.
