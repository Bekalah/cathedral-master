// Cathedral Characters Index
// Export all character profiles for use in Cathedral apps

import geminiRivers from './gemini-rivers.json';

export const characters = [
  geminiRivers
  // Add more character imports here
];

export default characters;
