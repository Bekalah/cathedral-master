# @cathedral/soul

Living Arcanae RPG/CYOA engine.

- Archetype frequency signatures
- Interference and resonance logic
- CYOA branching, narrator voices
