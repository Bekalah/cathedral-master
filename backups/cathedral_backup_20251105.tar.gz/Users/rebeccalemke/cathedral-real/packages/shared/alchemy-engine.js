// assets/js/alchemy-engine.js
// Alchemical fusion engine for 72 angels, zodiac, decans, and style merging

// ...existing AlchemyEngine code from your attachment...

// Export for use
window.AlchemyEngine = AlchemyEngine;