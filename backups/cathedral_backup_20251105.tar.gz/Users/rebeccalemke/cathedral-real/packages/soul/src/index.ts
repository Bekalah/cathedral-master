// Living Arcanae RPG/CYOA entry
export * from './archetypes';
