import { CrystalFusionSet } from '../types';
export declare const fusionSets: CrystalFusionSet[];
//# sourceMappingURL=fusionSets.d.ts.map