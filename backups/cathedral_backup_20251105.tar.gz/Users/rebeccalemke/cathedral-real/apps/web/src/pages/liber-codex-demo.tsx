// apps/web/src/pages/liber-codex-demo.tsx
import React from "react";
import LiberCodexDemo from "../components/liberCodexDemo";

export default function Page() {
  return (
    <main>
      <LiberCodexDemo />
    </main>
  );
}
