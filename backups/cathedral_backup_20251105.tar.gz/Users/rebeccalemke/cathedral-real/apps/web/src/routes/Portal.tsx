export default function Portal() {
  return (
    <div>
      <h1>Portal</h1>
    </div>
  );
}