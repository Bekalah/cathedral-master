import { Crystal } from '../types';
export declare const baseCrystals: Crystal[];
//# sourceMappingURL=baseCrystals.d.ts.map