// Shared utilities entry
