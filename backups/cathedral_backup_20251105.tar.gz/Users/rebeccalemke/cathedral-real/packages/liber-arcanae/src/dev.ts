// src/dev.ts — liber-arcanae minimal dev bootstrap (stub)
console.log("liber-arcanae — dev ready (Major & Minor Arcana placeholder)");
process.stdin.resume();
